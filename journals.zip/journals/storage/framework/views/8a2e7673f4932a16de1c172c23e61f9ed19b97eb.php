<div class="jf-courserequests">
    <figure class="jf-bannerbg">
        <img src="<?php echo e(asset('/images/banner-img.png')); ?>">
    </figure>
    <div class="jf-addcourse">
        <div class="jf-bannercontent">
            <div class="jf-description">
                <p><?php echo e(trans('prs.no_record')); ?></p>
            </div>
        </div>
    </div>
</div>