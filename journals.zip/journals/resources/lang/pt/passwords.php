<?php 

return [
    'password' => 'As senhas devem ter pelo menos seis caracteres e corresponder à confirmação.',
    'reset' => 'Sua senha foi alterada!',
    'sent' => 'Nós enviamos um e-mail para o seu link de redefinição de senha!',
    'token' => 'Este token de redefinição de senha é inválido.',
    'user' => 'Não conseguimos encontrar um usuário com esse endereço de e-mail.',
];