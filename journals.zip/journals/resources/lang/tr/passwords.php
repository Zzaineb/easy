<?php 

return [
    'password' => 'Şifreler en az altı karakter olmalı ve onay ile eşleşmelidir.',
    'reset' => 'Şifreniz sıfırlandı!',
    'sent' => 'Şifre sıfırlama bağlantınızı e-posta ile gönderdik!',
    'token' => 'Bu şifre sıfırlama belirteci geçersiz.',
    'user' => 'Biz bu e-posta adresine sahip bir kullanıcı bulamıyorum.',
];