<aside id="article_sidebar" class="sj-sidebar">
    @include('includes.widgets.recent-articles-widget')
    @include('includes.widgets.success-factor-widget')
    @include('includes.widgets.notice-board-widget')
    @include('includes.widgets.advertisment-widget')
</aside>
